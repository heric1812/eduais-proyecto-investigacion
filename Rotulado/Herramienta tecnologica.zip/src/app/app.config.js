(function() {
  'use strict';

  angular
    .module('redais')
    .config(AppConfig);

  AppConfig.$inject = [];
  /* @ngInject */
  function AppConfig() {

  }

})();
