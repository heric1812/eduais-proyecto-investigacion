(function() {
  'use strict';

  angular
    .module('redais')
    .controller('AppController', AppController);

  AppController.$inject = [];
  /* @ngInject */
  function AppController() {
    var vm = this;
    vm.title = 'AppController';
    console.log(vm.title);
  }
})();
