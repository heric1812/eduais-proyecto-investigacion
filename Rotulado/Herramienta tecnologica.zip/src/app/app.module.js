(function() {
  'use strict';

  angular
    .module('redais', [

      // Core
      'app.core',

      // Parte de los templates
      'app.toolbar',
      'app.navigation',

      // Página de bienvenida.
      'app.welcome',

      // Auth
      'app.auth',

      // Home
      'app.home',

      // Publication
      'app.publication',

      // Profile
      'app.profile',


      // 'app.landing',
      // 'app.layout',
      // 'app.waitList'
    ]);

})();
