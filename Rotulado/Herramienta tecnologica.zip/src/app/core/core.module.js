(function() {
  'use strict';

  angular
    .module('app.core', [
      // Angular modules
      'ui.router',
      'ngAnimate',
      'ngAria',
      'ngMaterial',
      'ngMessages',
      'ngSanitize',

      // Carga modular
      'oc.lazyLoad',

      // DB RealTime
      'firebase',

      // Plugin's
      'slickCarousel',
      'textAngular',
      'angularFileUpload'
    ]);
})();
