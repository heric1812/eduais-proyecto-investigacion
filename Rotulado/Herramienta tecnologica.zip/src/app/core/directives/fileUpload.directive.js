(function() {
  'use strict';

  angular
    .module('app.core')
    .directive('fileUpload', fileUpload);

  fileUpload.$inject = [];
  /* @ngInject */
  function fileUpload() {
    return {
      scope: {
        fileUpload: "="
      },
      link: function(scope,element,attributes) {
        element.bind("change", function (e) {
          scope.$apply(function () {
            // scope.fileUpload = e.target.files[0];
            // or all selected files:
            scope.fileUpload = e.target.files;
          });
        });
      }
      /*
      link: function (scope, element, attributes) {
        element.bind("change", function (changeEvent) {
          var reader = new FileReader();
          reader.onload = function (loadEvent) {
            scope.$apply(function () {
              scope.ngFileModel = {
                lastModified: changeEvent.target.files[0].lastModified,
                lastModifiedDate: changeEvent.target.files[0].lastModifiedDate,
                name: changeEvent.target.files[0].name,
                size: changeEvent.target.files[0].size,
                type: changeEvent.target.files[0].type,
                data: loadEvent.target.result
              };
            });
          }
          reader.readAsDataURL(changeEvent.target.files[0]);
          console.log(reader);
        });
      }
      */
    }
  }
})();