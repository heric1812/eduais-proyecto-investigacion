(function() {
  'use strict';

  angular
    .module('app.core')
    .filter('extension', function() {
      return function(text) {
        var rootURL, extension;
        rootURL = window.location.origin;
        /* el tipo de archivo lo convierto en arreglo para separa el type del formato. ejem: audio/mp4 a ['audio','mp4'] */
        extension = text.split('.');
        /* obtengo el ultimo valor del arreglo, en este caso el formato (extension) */
        extension = extension.pop();
        text = rootURL + '/static/image/icon/format/png/' + extension + '.png';
        return text;
      }
    })

    // Separar el primer nombre y retornarlo
    .filter('firstString', function() {
      return function(text) {
        text = text.split(' ')[0];
        return text;
      }
    })

    // Calcular la fecha de nacimiento y retornar la edad
    .filter('years', function() {
      return function(text) {
        var date = new Date();
        text = new Date(text);
        text = Number(date.getFullYear()) - Number(text.getFullYear());
        return text;
      }
    })

    .filter('bytes', function() {
      return function(bytes) {
        if(bytes == 0) return '0 Bytes';
        var units = ['bytes','KB','MB','GB','TB','PB','EB','ZB','YB'],
          n = parseInt(bytes, 10) || 0,
          l = 0;
        while(n >= 1024){
          n = n/1024;
          l++;
        }
        return(n.toFixed(n >= 10 || l < 1 ? 0 : 1) + ' ' + units[l]);
      }
    });
})();