(function() {
  'use strict';

  angular
    .module('app.core')
    .factory('Interceptor', Interceptor);

  Interceptor.$inject = ['$rootScope','$q'];
  /* @ngInject */
  function Interceptor($rootScope,$q) {
    var service = {
      request: request,
      requestError: requestError,
      response: response,
      responseError: responseError
    }
    return service;

    ///////////

    function request(config) {
      $rootScope.loadingProgress = true;
      //console.log('preload true', config);
      //$rootScope.$broadcast('loading:show');
      return config;
    }

    function requestError(rejection) {
      $rootScope.loadingProgress = false;
      //console.log('preload false', rejection);
      //$rootScope.$broadcast('loading:hide');
      return rejection;
    }

    function response(response) {
      $rootScope.loadingProgress = false;
      //console.log('preload true', response);
      //$rootScope.$broadcast('loading:hide');
      return response;
    }

    function responseError(rejection) {
      $rootScope.loadingProgress = false;
      //console.log('preload false', rejection);
      //$rootScope.$broadcast('loading:hide');
      return $q.reject(rejection);
    }
  }

})();