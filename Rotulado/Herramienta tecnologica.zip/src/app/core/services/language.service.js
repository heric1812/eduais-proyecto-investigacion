(function() {
  'use strict';

  angular
    .module('app.core')
    .factory('LanguageService', LanguageService);

  LanguageService.$inject = ['$firebaseArray','$firebaseObject','FirebaseDataService','AuthService'];
  /* @ngInject */
  function LanguageService($firebaseArray,$firebaseObject,FirebaseDataService,AuthService) {
    var ref = FirebaseDataService.languages;
    var service = {
      addLang: addLang,
      editLang: editLang,
      deleteLang: deleteLang,
      loadLang: loadLang,
    };
    return service;

    function addLang(lang) {
      var obj = $firebaseArray(ref);
      return obj.$add({
        userId: AuthService.isLoggedIn().uid,
        idioma: lang.language,
        nivel: lang.level,
        timestamp: firebase.database.ServerValue.TIMESTAMP
      });
    }

    function editLang(lang) {
      var obj = $firebaseObject(ref.child(lang.$id));

      obj.userId = AuthService.isLoggedIn().uid;
      obj.idioma = lang.idioma;
      obj.nivel = lang.nivel;
      obj.timestamp = firebase.database.ServerValue.TIMESTAMP;

      return obj.$save();
    }

    function deleteLang(uid) {
      return $firebaseObject(ref.child(uid)).$remove();
    }

    function loadLang(uid) {
      return $firebaseArray(ref.orderByChild('userId').equalTo(uid));
    }

  }

})();