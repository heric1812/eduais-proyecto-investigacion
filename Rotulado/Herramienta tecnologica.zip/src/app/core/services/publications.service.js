(function() {
  'use strict';

  angular
    .module('app.core')
    .factory('PublicationService', PublicationService);

  PublicationService.$inject = ['$firebaseArray','FirebaseDataService','UserService'];
  /* @ngInject */
  function PublicationService($firebaseArray,FirebaseDataService,UserService) {
    var ref = FirebaseDataService.publication;
    var service = {
      newPublication: newPublication,
      list: list,
      loadPublication: loadPublication
    };
    return service;

    ////////////////

    /**
     * Añadir
     *
     * @param: data
     *
     * @desc: Crea una nueva publicación
     */
    function newPublication(data) {
      var obj = $firebaseArray(ref);
      var user = UserService.getUserAuth();
      return obj.$add({
        userId: user.uid,
        userName: user.name,
        userAvatar: user.avatar,
        userSlug: user.slug,
        titulo: data.titulo,
        descripcion: data.descripcion,
        materia: data.materia,
        adjuntos: data.adjuntos,
        timestamp: firebase.database.ServerValue.TIMESTAMP
      });
    }

    /**
     * Lista
     *
     * @param:
     *
     * @desc: Lista todas las publicaciones
     */
    function list() {
      //var publicationRef = FirebaseDataService.publication.orderByChild('created').limitToLast(5);
      return $firebaseArray(ref.limitToLast(5));
    }

    function loadPublication(uid) {
      return $firebaseArray(ref.orderByChild('userId').equalTo(uid));
    }

  }
})();
