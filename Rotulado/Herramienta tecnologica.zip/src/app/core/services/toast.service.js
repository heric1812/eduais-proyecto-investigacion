(function() {
  'use strict';

  angular
    .module('app.core')
    .factory('ToastService',ToastService);

  ToastService.$inject = ['$mdToast'];
  /* @ngInject */
  function ToastService($mdToast) {
    var service = {
      msg: msg,
      success: success,
      error: error,
      warning: warning
    };
    return service;

    //////////

    /**
     * Mensaje normal
     *
     * @param: icon, msg
     *
     * @desc: Toast para mostrar un mensaje normal
     */
    function msg(icon,msg) {
      $mdToast.show({
        hideDelay: 3000,
        position: 'top right',
        template:
        '  <md-toast>' +
        '   <span class="md-toast-icon"><i class="fa '+icon+'"></i></span>' +
        '   <span class="md-toast-text" flex>'+msg+'</span>' +
        ' </md-toast>'
      });
    }

    /**
     * Mensaje aprovado
     *
     * @param: msg
     *
     * @desc: Mostrar un mensaje de aprovado
     */
    function success(msg) {
      $mdToast.show({
        hideDelay: 3000,
        position: 'top right',
        template:
        ' <md-toast>' +
        '   <span class="md-toast-icon success"><i class="fa fa-check-circle"></i></span>' +
        '   <span class="md-toast-text" flex>'+ msg +'</span>' +
        ' </md-toast>'
      });
    }

    /**
     * Mensaje error
     *
     * @param: msg
     *
     * @desc: Mostrar un mensaje de error
     */
    function error(msg) {
      $mdToast.show({
        hideDelay: 3000,
        position: 'top right',
        template:
        ' <md-toast>' +
        '   <span class="md-toast-icon error"><i class="fa fa-times-circle"></i></span>' +
        '   <span class="md-toast-text" flex>'+ msg +'</span>' +
        ' </md-toast>'
      });
    }

    /**
     * Mensaje alerta
     *
     * @param: msg
     *
     * @desc: Mostrar un mensaje de alerta
     */
    function warning(msg) {
      $mdToast.show({
        hideDelay: 3000,
        position: 'top right',
        template:
        ' <md-toast>' +
        '   <span class="md-toast-icon warning"><i class="fa fa-chat"></i></span>' +
        '   <span class="md-toast-text" flex>'+ msg +'</span>' +
        ' </md-toast>'
      });
    }
  }

})();
