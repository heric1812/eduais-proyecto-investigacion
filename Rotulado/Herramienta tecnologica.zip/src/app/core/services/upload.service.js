(function() {
  'use strict';

  angular
    .module('app.core')
    .factory('UploadService', UploadService);

  UploadService.$inject = ['UploadDataService'];
  /* @ngInject */
  function UploadService(UploadDataService) {
    var service = {
      upload: upload
    };
    return service;

    /** Subir archivo
     *
     * @param: file, user
     *
     * @desc: Subir los archivos al servidor de storage de firebase
     */
    function upload(file, user) {
      console.log(user);
      console.log(file);
    }

  }

})();