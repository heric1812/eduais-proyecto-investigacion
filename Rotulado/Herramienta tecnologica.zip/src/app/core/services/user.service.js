(function() {
  'use strict';

  angular
    .module('app.core')
    .factory('UserService', UserService);

  UserService.$inject = ['$firebaseObject','FirebaseDataService','AuthService'];
  /* @ngInject */
  function UserService($firebaseObject,FirebaseDataService,AuthService) {
    var ref = FirebaseDataService.profile;
    var service = {
      save: save,
      getUserProfile: getUserProfile,
      getUserAuth: getUserAuth
    };
    return service;

    function save(profile) {
      var uid = AuthService.isLoggedIn().uid;
      var obj = $firebaseObject(ref.child(uid));

      obj.avatar = profile.avatar;
      obj.nombres = profile.nombres;
      obj.apellidos = profile.apellidos;
      obj.cedula = profile.cedula;
      obj.sexo = profile.sexo;
      obj.fechaNacimiento = Date.parse(profile.fechaNacimiento);
      obj.profesion = profile.profesion;
      obj.telefonos = profile.telefonos;
      obj.emails = profile.emails;
      obj.acercaMi = profile.acercaMi;
      obj.queHago = profile.queHago;
      obj.nivel = profile.nivel;
      obj.status = profile.status;
      obj.slug = profile.slug;
      obj.updated = firebase.database.ServerValue.TIMESTAMP;

      return obj.$save();
    }

    /** Obtener de perfil del usuario
     *
     * @param:
     *
     * @desc: Se obtienen los datos del perfil
     */
    function getUserProfile(uid) {
      return $firebaseObject(ref.child(uid));
      // return $firebaseObject(FirebaseDataService.profile.orderByChild('userId').equalTo(uid));
    }

    /** Obtener de auth del usuario
     *
     * @param:
     *
     * @desc: Se obtienen los datos de autenticación del usuario
     */
    function getUserAuth() {
      var UserAuth = AuthService.isLoggedIn();
      var user = {
        uid: UserAuth.uid,
        avatar: UserAuth.photoURL,
        name: UserAuth.displayName.split('/')[0],
        level: Number(UserAuth.displayName.split('/')[1]),
        slug: UserAuth.displayName.split('/')[2]
      };
      return user;
    }

  }

})();