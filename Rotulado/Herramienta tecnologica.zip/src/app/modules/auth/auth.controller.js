(function() {
  'use strict';

  angular
    .module('app.auth')
    .controller('AuthController', AuthController);

  AuthController.$inject = ['$state','AuthService','ToastService','CODE'];

  function AuthController($state,AuthService,ToastService,CODE) {
    var vm = this;
    var myDate = new Date();

    vm.title = 'AuthController';
    vm.error = null;
    vm.reCaptcha = {
      key: "6LcdvQ0UAAAAAKv127JW1ibIhFO-jow7x7tpRvv8"
    };

    // metodos
    vm.register = register;
    vm.login = login;
    vm.loginFacebook = loginFacebook;
    vm.loginGoogle = loginGoogle;
    vm.recoverPassword = recoverPassword;

    //////////

    activate();

    /**
     * Registro
     *
     * @param: user
     *
     * @desc: Registra al usuario en la DB
     */
    function register(user) {
      user.avatar = 'http://lorempixel.com/200/200/abstract/9/';
      if (user.code) {
        if (user.code === CODE) {
          user.nivel = 1;
          return create(user);
        } else {
          vm.error = 'Código incorrecto, verifique eh intente nuevamente.';
        }
      } else {
        user.nivel = 2;
        return create(user);
      }
    }

    /**
     * Crear
     *
     * @param: user
     *
     * @desc: Crea el perfil del usuario en la DB
     */
    function create(user) {
      return AuthService.register(user)
        .then(function(response) {
          return AuthService.createProfile(response.uid, user);
        })
        .then(function() {
          console.log('Actualizando profile de auth');
          return AuthService.updateProfile(user);
        })
        .then(function() {
          ToastService.success('Registro exitoso!!');
          return vm.login(user);
        })
        .catch(function(error) {
          msgError(error.code);
          console.error('error: ', error);
        });
    }



    /**
     * Login
     *
     * @param: user
     *
     * @desc: Verifica las credenciales del usuario para poder acceder al sistema.
     */
    function login(user) {
      return AuthService.login(user)
        .then(function() {
          ToastService.success('Bienvenido');
          $state.go('app.home');
        })
        .catch(function(error) {
          msgError(error.code);
          console.error('error: ', error);
        });
    }

    /**
     * Login por Facebook
     *
     * @param:
     *
     * @desc: Loguea al usuario con su cuenta de facebook
     */
    function loginFacebook() {
      return AuthService.facebook()
        .then(function(response) {
          console.info(response);
          ToastService.success('Logueo exitoso!');
          $state.go('app.home');
        })
        .catch(function(error) {
          msgError(error.code);
          console.error('error: ', error);
        });
    }

    /**
     * Login por Google
     *
     * @param:
     *
     * @desc: Loguea al usuario con su cuenta de google
     */
    function loginGoogle() {
      return AuthService.google()
        .then(function(response) {
          console.info(response);
          ToastService.success('Logueo exitoso!');
          $state.go('app.home');
        })
        .catch(function(error) {
          msgError(error.code);
          console.error('error: ', error);
        });
    }

    /**
     * Recuperar contraseña
     *
     * @param: recover
     *
     * @desc: Envia los datos para recuperar la contraseña del usuario
     */
    function recoverPassword(recover) {
      console.log(recover);
    }

    /**
     * Mensajes de error
     *
     * @param: error
     *
     * @desc: Envia a la variable vm.error un error correspondiente enviado por firebase
     */
    function msgError(error) {
      /* Errores generales */
      if (error === 'auth/network-request-failed') {
        vm.error = 'Se produjo un error de conexión, verifique e intente nuevamente.';
      }
      /* Errores del registro */
      else if (error === 'auth/email-already-in-use') {
        vm.error = 'La dirección de correo electrónico ya está en uso por otra cuenta.';
      } else if (error === 'auth/weak-password') {
        vm.error = 'La contraseña debe tener más de 6 caracteres.';
      }
      /* Errores del login */
      else if (error === 'auth/wrong-password') {
        vm.error = 'La contraseña no es válida o el usuario no tiene una contraseña.';
      } else if (error === 'auth/user-not-found') {
        vm.error = 'No hay registro del usuario. O el usuario pudo haber sido eliminado.';
      } else if (error === 'auth/too-many-requests') {
        vm.error = 'Hemos bloqueado todas las peticiones de este dispositivo debido a la actividad inusual. Inténtelo de nuevo más tarde.';
      }
      /* Errores de login social */
      else if (error === 'auth/popup-closed-by-user') {
        vm.error = null;
      }
    }

    /**
     * Activate
     *
     * @param:
     *
     * @desc: Función que se inicia al cargar el controlador.
     */
    function activate() {
      console.log(vm.title);
    }
  }

})();
