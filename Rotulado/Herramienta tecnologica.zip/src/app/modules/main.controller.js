(function () {
  'use strict';

  angular
    .module('redais')
    .controller('MainController', MainController);

  MainController.$inject = ['$scope','$rootScope'];
  /* @ngInject */
  function MainController($scope,$rootScope) {
    var vm = this;

    // metodos

    //////////

    activate();

    /**
     * Scope On
     *
     * @param:
     *
     * @desc: Remover el splash screen (icono de carga).
     */
    // $scope.$on('$viewContentAnimationEnded', function (event) {
    //   if ( event.targetScope.$id === $scope.$id ) {
    //     $rootScope.$broadcast('msSplashScreen::remove');
    //   }
    // });


    /**
     * Activate
     *
     * @param:
     *
     * @desc: Función que se activa al cargar el controlador
     */
    function activate() {
    }

  }
})();
