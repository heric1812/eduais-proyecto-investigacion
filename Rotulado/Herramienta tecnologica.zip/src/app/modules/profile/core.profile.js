(function(){
  'use strict';

  angular
    .module('app.profile', [])
    .config(Configurate);

  Configurate.$inject = ['$stateProvider'];
  /* @ngInject */
  function Configurate($stateProvider) {
    $stateProvider
      .state('app.profile', {
        url: '/profile/:slug/:uid',
        // abstract: false,
        cache: false,
        views: {
          'content@app': {
            templateUrl: function($stateParams) {
              if ($stateParams.uid===firebase.auth().currentUser.uid) {
                return 'app/modules/profile/profileAuth.html';
              } else {
                return 'app/modules/profile/profileView.html';
              }
            },
            controller: 'ProfileController as vm'
          }
        },
        resolve: {
          User: ResolveUser,
          Profile: ResolveProfile,
          Publication: ResolvePublication,
          Lang: ResolveLang,
          Experience: ResolveExperience,
          Skill: ResolveSkill
        },
        bodyClass: 'profile',
      });
  }

  ResolveUser.$inject = ['AuthService'];
  /* @ngInject */
  function ResolveUser(AuthService) {
    return AuthService.firebaseAuthObject.$requireSignIn();
  }

  ResolveProfile.$inject = ['$stateParams','UserService'];
  /* @ngInject */
  function ResolveProfile($stateParams,UserService) {
    // return $firebaseObject(FirebaseDataService.profile.child($stateParams.uid));
    return UserService.getUserProfile($stateParams.uid);
  }

  ResolvePublication.$inject = ['$stateParams','PublicationService'];
  /* @ngInject */
  function ResolvePublication($stateParams,PublicationService) {
    // return $firebaseArray(firebase.database().ref().child('idiomas').orderByChild('userId').equalTo($stateParams.uid));
    return PublicationService.loadPublication($stateParams.uid);
  }

  ResolveLang.$inject = ['$stateParams','LanguageService'];
  /* @ngInject */
  function ResolveLang($stateParams,LanguageService) {
    // return $firebaseArray(firebase.database().ref().child('idiomas').orderByChild('userId').equalTo($stateParams.uid));
    return LanguageService.loadLang($stateParams.uid);
  }

  ResolveExperience.$inject = ['$stateParams','ExperienceService'];
  /* @ngInject */
  function ResolveExperience($stateParams,ExperienceService) {
    // return $firebaseArray(firebase.database().ref().child('experiencias').orderByChild('userId').equalTo($stateParams.uid));
    return ExperienceService.loadExp($stateParams.uid);
  }

  ResolveSkill.$inject = ['$stateParams','ExperienceService'];
  /* @ngInject */
  function ResolveSkill($stateParams,ExperienceService) {
    // return $firebaseArray(firebase.database().ref().child('habilidades').orderByChild('userId').equalTo($stateParams.uid));
    return ExperienceService.loadSkill($stateParams.uid);
  }

})();
