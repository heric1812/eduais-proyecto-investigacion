(function(){
  'use strict';

  angular
    .module('app.profile')
    .controller('ProfileController', ProfileController)
    .controller('MainInformationController', MainInformationController)
    .controller('ExperienceController', ExperienceController)
    .controller('EditExperienceController', EditExperienceController)
    .controller('SkillController', SkillController)
    .controller('EditSkillController', EditSkillController);

  ProfileController.$inject = ['$scope','$firebaseObject','$mdDialog','User','Profile','Publication','Lang','Experience','Skill','UserService','LanguageService','ToastService'];
  /* @ngInject */
  function ProfileController($scope,$firebaseObject,$mdDialog,User,Profile,Publication,Lang,Experience,Skill,UserService,LanguageService,ToastService) {
    var vm = this;
    // Extras
    vm.parentEl= angular.element(document.body);
    vm.myDate = new Date();
    vm.minDate = new Date(
      vm.myDate.getFullYear() - 70,
      vm.myDate.getMonth(),
      vm.myDate.getDate());
    vm.maxDate = new Date(
      vm.myDate.getFullYear() - 16,
      vm.myDate.getMonth(),
      vm.myDate.getDate());

    // Data
    vm.userAuth = User;
    vm.userProfile = Profile;
    vm.userPublication = Publication;
    vm.userLang = Lang;
    vm.userExperience = Experience;
    vm.userSkill = Skill;


    vm.listLanguages = ['Español','Ingles','Frances','Japones'];

    // show y hide view
    vm.mainInfo = false;
    vm.aboutMy = false;
    vm.lenguaje = false;
    vm.progressAvatar = false;

    // metodos
    vm.save = save;

    vm.addLang = addLang;
    vm.editLang = editLang;
    vm.deleteLang = deleteLang;

    // Dialogs
    vm.openPublication = openPublication;
    vm.newPublication = newPublication;
    vm.editMain = editMain;
    vm.addWorkExperience = addWorkExperience;
    vm.addEducationalExperience = addEducationalExperience;
    vm.editExperience = editExperience;
    vm.deleteExperience = deleteExperience;
    vm.addSkill = addSkill;
    vm.editSkill = editSkill;
    vm.deleteSkill = deleteSkill;

    //////////

    activate();

    $scope.$watch('vm.avatar', function(newVal, oldVal) {
      console.log('newVal: ',newVal);
      console.log('oldVal: ',oldVal);
      if (newVal) {
        var file = newVal[0];
        var name = vm.userProfile.uid+'.png';
        console.info(file);
        var storage = firebase.storage().ref().child(vm.userAuth.uid).child('avatar').child(name);
        var uploadTask = storage.put(file);

        uploadTask.on('state_changed',
          function(snapshot) {
            vm.progressAvatar = Math.floor((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
            console.info('subiendo: '+vm.progressAvatar+'%');
            $scope.$apply();
          },
          function(err) {
            // funcion al generarse un error
            console.error(err);
          },
          function() {
            console.info(uploadTask.snapshot);
            vm.progressAvatar = false;
            vm.userProfile.avatar = uploadTask.snapshot.downloadURL;
            var userUpdate = firebase.auth().currentUser;
            userUpdate.updateProfile({
              photoURL: uploadTask.snapshot.downloadURL
            });
            console.info(vm.userProfile);
            save();
          }
        );
      } else {
        console.log('0 avatar');
      }
    });

    /** Guardar data del perfil
     *
     * @param:
     *
     * @desc: Guarda información del usuario en el perfil
     */
    function save() {
      vm.userProfile.fechaNacimiento = vm.userProfile.fechaNacimiento.toString();
      vm.userProfile.updated = firebase.database.ServerValue.TIMESTAMP;
      // return UserService.save(vm.userProfile)
      vm.userProfile.$save()
        .then(function(response) {
          ToastService.success('Guardado con exito');
        })
        .catch(function(error) {
          ToastService.error('Error al guardar');
        });
    }

    /** Añadir un idioma
     *
     * @param: lang
     *
     * @desc: Guarda el idioma del usuario
     */
    function addLang(lang) {
      return LanguageService.addLang(lang)
        .then(function(response) {
          ToastService.success('Idioma guardado');
        })
        .catch(function(error) {
          ToastService.error('Error al guardar');
        });
    }

    function editLang(lang) {
      return LanguageService.editLang(lang)
        .then(function(response) {
          console.info(response);
          ToastService.success('Idioma actualizado');
        })
        .catch(function(error) {
          console.error(error);
          ToastService.error('Error al actualizar');
        });
    }

    function deleteLang(uid) {
      return LanguageService.deleteLang(uid)
        .then(function(response) {
          console.info(response);
          ToastService.success('Idioma eliminado');
        })
        .catch(function(error) {
          console.error(error);
          ToastService.error('Error al eliminar');
        });
    }

    /**
     * Activate
     *
     * @param:
     *
     * @desc: Esta función se activará automáticamente al cargarse el controlador.
     */
    function activate() {
    }

    /**
     * Abrir publicación
     *
     * @param: ev, uid
     *
     * @desc: Abrir una ventana de dialogo para la ver una publicación
     */
    function openPublication(ev,uid) {
      $mdDialog.show({
        controller: 'ViewPublicationController as vm',
        templateUrl: 'app/modules/publication/dialog/view-publication.html',
        parent: angular.element(document.body),
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false, // Only for -xs, -sm breakpoints.
        locals: {
          Id: uid
        }
      });
    }

    /**
     * Nueva publicación
     *
     * @param: ev
     *
     * @desc: Abrir una ventana de dialogo para la creación de una nueva publicación
     */
    function newPublication(ev) {
      $mdDialog.show({
        controller: 'NewPublicationController as vm',
        templateUrl: 'app/modules/publication/dialog/new-publication.html',
        parent: angular.element(document.body),
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false // Only for -xs, -sm breakpoints.
      });
    }

    /**
     * Editar infomación principal del perfil
     *
     * @param: ev
     *
     * @desc: Abrir una ventana de dialogo para editar la información del perfil
     */
    function editMain(ev) {
      $mdDialog.show({
        controller: 'MainInformationController as vm',
        templateUrl: 'app/modules/profile/dialog/edit-main-information.html',
        parent: vm.parentEl,
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false, // Only for -xs, -sm breakpoints.
        locals: {
          userProfile: vm.userProfile
        }
      });
    }

    /**
     * Añadir experiencia laboral
     *
     * @param: ev
     *
     * @desc: Abrir una ventana de dialogo para añadir una experiencia laboral
     */
    function addWorkExperience(ev) {
      $mdDialog.show({
        controller: 'ExperienceController as vm',
        templateUrl: 'app/modules/profile/dialog/experience.html',
        parent: vm.parentEl,
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false, // Only for -xs, -sm breakpoints.
        locals: {
          typeExperience: 'Trabajo'
        }
      });
    }

    /**
     * Añadir experiencia educativa
     *
     * @param: ev
     *
     * @desc: Abrir una ventana de dialogo para añadir una experiencia educativa
     */
    function addEducationalExperience(ev) {
      $mdDialog.show({
        controller: 'ExperienceController as vm',
        templateUrl: 'app/modules/profile/dialog/experience.html',
        parent: vm.parentEl,
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false, // Only for -xs, -sm breakpoints.
        locals: {
          typeExperience: 'Educación'
        }
      });
    }

    /**
     * Editar experiencia
     *
     * @param: ev, uid
     *
     * @desc: Abrir una ventana de dialogo para editar la experiencia seleccionada
     */
    function editExperience(ev,uid) {
      $mdDialog.show({
        controller: 'EditExperienceController as vm',
        templateUrl: 'app/modules/profile/dialog/experience.html',
        parent: vm.parentEl,
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false, // Only for -xs, -sm breakpoints.
        locals: {
          Data: $firebaseObject(firebase.database().ref().child('experiencias').child(uid)),
        }
      });
    }

    /**
     * Elimina experiencia
     *
     * @param: uid
     *
     * @desc: Elimina la experiencia seleccionada
     */
    function deleteExperience(uid) {
      return $firebaseObject(firebase.database().ref().child('experiencias').child(uid)).$remove()
        .then(function(response) {
          ToastService.success('Eliminado correctamente');
        })
        .catch(function(error) {
          ToastService.error('Error al eliminar');
        });
    }

    /**
     * Añadir una habilidad personal
     *
     * @param: ev
     *
     * @desc: Abrir una ventana de dialogo para añadir una habilidad personal
     */
    function addSkill(ev) {
      $mdDialog.show({
        controller: 'SkillController as vm',
        templateUrl: 'app/modules/profile/dialog/skill.html',
        parent: vm.parentEl,
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false // Only for -xs, -sm breakpoints.
      });
    }

    /**
     * Editar habilidad personal
     *
     * @param: ev, uid
     *
     * @desc: Abrir una ventana de dialogo para editar la habilidad seleccionada
     */
    function editSkill(ev,uid) {
      $mdDialog.show({
        controller: 'EditSkillController as vm',
        templateUrl: 'app/modules/profile/dialog/skill.html',
        parent: vm.parentEl,
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false, // Only for -xs, -sm breakpoints.
        locals: {
          Data: $firebaseObject(firebase.database().ref().child('habilidades').child(uid)),
        }
      });
    }

    /**
     * Elimina habilidad
     *
     * @param: uid
     *
     * @desc: Elimina la habilidad seleccionada
     */
    function deleteSkill(uid) {
      return $firebaseObject(firebase.database().ref().child('habilidades').child(uid)).$remove()
        .then(function(response) {
          ToastService.success('Eliminado correctamente');
        })
        .catch(function(error) {
          ToastService.error('Error al eliminar');
        });
    }

  }


  MainInformationController.$inject = ['$mdDialog','userProfile','ToastService'];
  /* @ngInject */
  function MainInformationController($mdDialog,userProfile,ToastService) {
    var vm = this;
    vm.userProfile = userProfile;

    // metodos
    vm.save = save;
    vm.pushPhone = pushPhone;
    vm.pushEmail = pushEmail;
    vm.cancel = cancel;

    //////////

    activate();

    /** Añadir data al perfil
     *
     * @param: data
     *
     * @desc: Guarda información del usuario en el perfil
     */
    function save() {
      vm.userProfile.$save()
        .then(function(response) {
          ToastService.success('Guardado con exito');
          cancel();
        })
        .catch(function(error) {
          ToastService.error('Error al guardar');
          console.log('Error al guardar', error);
        });
    }

    function pushPhone(phone) {
      if (vm.userProfile.telefonos) {
        vm.userProfile.telefonos.push(phone);
        save();
        vm.telefonos = null;
      } else {
        vm.userProfile.telefonos = [];
        vm.userProfile.telefonos.push(phone);
        save();
        vm.telefonos = null;
      }
    }

    function pushEmail(email) {
      if (vm.userProfile.emails) {
        vm.userProfile.emails.push(email);
        save();
        vm.emails = null;
      } else {
        vm.userProfile.emails = [];
        vm.userProfile.emails.push(email);
        save();
        vm.emails = null;
      }
    }

    /**
     * Cancelar
     *
     * @param:
     *
     * @desc: Cancela la ventana de dialogo
     */
    function cancel() {
      $mdDialog.cancel();
    }

     /**
     * Activate
     *
     * @param:
     *
     * @desc: Esta función se activará automáticamente al cargarse el controlador.
     */
    function activate() {
    }
  }


  ExperienceController.$inject = ['$mdDialog','typeExperience','ExperienceService','ToastService'];
  /* @ngInject */
  function ExperienceController($mdDialog,typeExperience,ExperienceService,ToastService) {
    var vm = this;
    vm.typeTitle = typeExperience==='Trabajo' ? vm.typeTitle='empresa' : vm.typeTitle='institución' ;
    vm.data = {
      tipo: typeExperience
    };

    // metodos
    vm.add = add;
    vm.cancel = cancel;

    //////////

    activate();

    /**
     * Guardar
     *
     * @param: data
     *
     * @desc: Guarda o edita el nombre, telefonos y emails del usuario
     */
    function add(experience) {
      console.log(experience);
      return ExperienceService.addExp(experience)
        .then(function(response) {
          ToastService.success('Guardado con exito');
          cancel();
        })
        .catch(function(error) {
          ToastService.error('Error al guardar');
        });
    }

    /**
     * Cancelar
     *
     * @param:
     *
     * @desc: Cancela la ventana de dialogo
     */
    function cancel() {
      $mdDialog.cancel();
    }

     /**
     * Activate
     *
     * @param:
     *
     * @desc: Esta función se activará automáticamente al cargarse el controlador.
     */
    function activate() {
    }
  }


  EditExperienceController.$inject = ['$mdDialog','Data','ToastService'];
  /* @ngInject */
  function EditExperienceController($mdDialog,Data,ToastService) {
    var vm = this;
    vm.data = Data;
    vm.data.fechaInicio = new Date(Data.fechaInicio);
    vm.data.fechaFin = new Date(Data.fechaFin);

    // metodos
    vm.add = add;
    vm.cancel = cancel;

    //////////

    activate();

    /**
     * Guardar
     *
     * @param: data
     *
     * @desc: Guarda o edita el nombre, telefonos y emails del usuario
     */
    function add(experience) {
      vm.data.fechaInicio = Date.parse(vm.data.fechaInicio);
      vm.data.fechaFin = Date.parse(vm.data.fechaFin);
      return vm.data.$save()
        .then(function(response) {
          ToastService.success('Guardado con exito');
          cancel();
        })
        .catch(function(error) {
          ToastService.error('Error al guardar');
        });
    }

    /**
     * Cancelar
     *
     * @param:
     *
     * @desc: Cancela la ventana de dialogo
     */
    function cancel() {
      $mdDialog.cancel();
    }

     /**
     * Activate
     *
     * @param:
     *
     * @desc: Esta función se activará automáticamente al cargarse el controlador.
     */
    function activate() {
    }
  }


  SkillController.$inject = ['$firebaseArray','$mdDialog','ExperienceService','ToastService'];
  /* @ngInject */
  function SkillController($firebaseArray,$mdDialog,ExperienceService,ToastService) {
    var vm = this;
    vm.data = null;
    vm.listSkill = ExperienceService.loadListSkill().$loaded()
      .then(function(response) {
        vm.listSkill = response;
      })
      .catch(function(error) {
        console.error('No se pudieron cargar los datos. Cierre el modal y vuelvalo a abrir.');
        vm.error = 'No se pudieron cargar los datos. Cierre el modal y vuelvalo a abrir.';
      });

    // metodos
    vm.save = save;
    vm.cancel = cancel;

    //////////

    activate();
    /**
     * Guardar
     *
     * @param: data
     *
     * @desc: Guarda o edita el nombre, telefonos y emails del usuario
     */
    function save(skill) {
      return ExperienceService.addSkill(skill)
        .then(function(response) {
          ToastService.success('Guardado con exito');
          cancel();
        })
        .catch(function(error) {
          ToastService.error('Error al guardar');
        });
    }

    /**
     * Cancelar
     *
     * @param:
     *
     * @desc: Cancela la ventana de dialogo
     */
    function cancel() {
      $mdDialog.cancel();
    }

     /**
     * Activate
     *
     * @param:
     *
     * @desc: Esta función se activará automáticamente al cargarse el controlador.
     */
    function activate() {
    }
  }


  EditSkillController.$inject = ['$mdDialog','Data','ToastService'];
  /* @ngInject */
  function EditSkillController($mdDialog,Data,ToastService) {
    var vm = this;
    vm.data = Data;

    // metodos
    vm.save = save;
    vm.cancel = cancel;

    //////////

    activate();

    /**
     * Guardar
     *
     * @param: data
     *
     * @desc: Guarda o edita el nombre, telefonos y emails del usuario
     */
    function save(skill) {
      // return ExperienceService.addSkill(skill)
      return vm.data.$save()
        .then(function(response) {
          ToastService.success('Guardado con exito');
          cancel();
        })
        .catch(function(error) {
          ToastService.error('Error al guardar');
        });
    }

    /**
     * Cancelar
     *
     * @param:
     *
     * @desc: Cancela la ventana de dialogo
     */
    function cancel() {
      $mdDialog.cancel();
    }

     /**
     * Activate
     *
     * @param:
     *
     * @desc: Esta función se activará automáticamente al cargarse el controlador.
     */
    function activate() {
    }
  }

})();
