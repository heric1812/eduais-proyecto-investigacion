(function() {
  'use strict';

  angular
    .module('app.publication', [])
    .config(Configurate);

  Configurate.$inject = ['$stateProvider'];
  /* @ngInject */
  function Configurate($stateProvider) {
    $stateProvider
      .state('app.publication', {
        url: '/publication/:slug',
        cache: false,
        views: {
          'content@app': {
            templateUrl: 'app/modules/publication/publication.html',
            controller: 'PublicationController as vm'
          }
        },
        bodyClass: 'publication',
        resolve: {
          User: ResolveUser
        //   load: ['$ocLazyLoad', function ($ocLazyLoad) {
        //           return $ocLazyLoad.load([
        //             // Array de todos los archivos que se deban cargar
        //             "app/modules/home/home.controller.js"
        //           ]).then(function() {
        //               // inject de modulos
        //               // angular.inject();
        //             },
        //             function(e) {
        //               console.log('err: ',e);
        //             });
        //         }]
        }
      });
  }

  ResolveUser.$inject = ['AuthService'];
  /* @ngInject */
  function ResolveUser(AuthService) {
    return AuthService.firebaseAuthObject.$requireSignIn();
  }

})();
