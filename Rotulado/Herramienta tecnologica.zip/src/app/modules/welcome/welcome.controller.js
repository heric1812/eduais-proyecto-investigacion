(function() {
  'use strict';

  angular
    .module('app.welcome')
    .controller('WelcomeController', WelcomeController);

  WelcomeController.$inject = [];
  /* @ngInject */
  function WelcomeController() {
    var vm = this;
    vm.title = 'WelcomeController';

    // Configuración para el slick-text
    vm.slickText = {
      dots: false,
      arrows: false,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: false,
      autoplaySpeed: 5000,
      // fade: true,
      asNavFor: '.slick-image'
    };

    // Configuración para el slick-image
    vm.slickImage = {
      dots: true,
      arrows: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 5000,
      fade: true,
      asNavFor: '.slick-text',
      focusOnSelect: true
    };

    // metodos
    vm.down = down;

    //////////

    activate();

    /**
     * Bajar
     *
     * @param:
     *
     * @desc: Permite bajar al siguiente elemento tomando el height del elemento padre
     */
    function down() {
      jQuery('body, html').animate({
        scrollTop: jQuery('#inicio').innerHeight() + 'px'
      }, 1000);
    }

    /**
     * Activate
     *
     * @param:
     *
     * @desc: Función que se inicia al cargar el controlador.
     */
    function activate() {
      console.log(vm.title);

      jQuery(window).on('scroll', function() {
        if (jQuery(window).scrollTop() > 0) {
          jQuery('header').addClass('navigation-top md-whiteframe-1dp');
        } else {
          jQuery('header').removeClass('navigation-top md-whiteframe-1dp');
        }
      });

    }

  }

})();
