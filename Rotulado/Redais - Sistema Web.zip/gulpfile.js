var gulp = require('gulp');
var sass = require('gulp-sass');
var concat = require('gulp-concat');
var sourcemaps = require('gulp-sourcemaps');
var prefix = require('gulp-autoprefixer');
var browserSync = require('browser-sync').create();

var paths = {
	all: ['src/**/*.html', 'src/**/*.js', 'src/**/*.json'],
	scss: ['src/**/*.scss', '!src/static/libs', '!src/static/libs/**'],
	css: 'src/static/css'
};

// Sass compile and auto inject BrowserSync
gulp.task('scss', function() {
	return gulp.src(paths.scss)
		.pipe(sourcemaps.init())
		.pipe(sass({ outputStyle: 'compressed' }).on('error', sass.logError))
		.pipe(prefix({ browsers: ['last 2 versions'] }))
		.pipe(concat('app.min.css'))
		.pipe(sourcemaps.write())
		.pipe(gulp.dest(paths.css))
		.pipe(browserSync.stream());
});

// BrowserSync server
gulp.task('serve', ['scss'], function() {

	browserSync.init({
		notify: true,
		server: './src'
	});

	gulp.watch(paths.scss, ['scss']);
	gulp.watch(paths.all).on('change', browserSync.reload);
});

gulp.task('default', ['serve']);
