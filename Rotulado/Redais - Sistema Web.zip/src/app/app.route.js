(function() {
  'use strict';

  angular
    .module('redais')
    .config(RouteConfig);

  RouteConfig.$inject = ['$httpProvider','$urlRouterProvider','$locationProvider','$stateProvider'];
  /* @ngInject */
  function RouteConfig($httpProvider,$urlRouterProvider,$locationProvider,$stateProvider) {

    $httpProvider.interceptors.push('Interceptor'); // La función del interceptor esta en /app/core/interceptor.service.js

    // $locationProvider.html5Mode(true); // Para que el navegador y las rutas acepten el modelo html5 eliminando el #

    $urlRouterProvider.otherwise('/'); // Ruta por defecto

    /**
     * Ruta principal
     *
     * @desc: Ruta abstracta principal de toda la aplicación.
     * Esta ruta sirve para llamar los template que se pintarán en el navegador.
     *
     */
    $stateProvider
      .state('app', {
        abstract: true,
        views: {
          'main@': {
            templateUrl: 'app/layouts/content/content-sidenav-left.html',
            controller: 'MainController as vm'
          },
          'toolbar@app': {
            templateUrl: 'app/layouts/toolbar/toolbar.html',
            controller: 'ToolbarController as vm'
          },
          'navigation@app': {
            templateUrl: 'app/layouts/navigation/navigation-teacher.html',
            controller: 'NavigationController as vm'
          },
          'footer@app': {
            templateUrl: 'app/layouts/footer/footer.html',
            controller: ''
          }
        }
      });
  }

})();
