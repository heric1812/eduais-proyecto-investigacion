(function() {
  'use strict';

  angular
    .module('redais')
    .run(RunFunction)
    .directive('loading',LoadingDirective);

  RunFunction.$inject = ['$rootScope','$state','$timeout','ToastService'];
  /* @ngInject */
  function RunFunction($rootScope,$state,$timeout,ToastService) {
    // Dar acceso rápido desde la vista al $state para el cambio de clase.
    $rootScope.state = $state;

    // Activar indicador de carga
    var stateChangeStartEvent = $rootScope.$on('$stateChangeStart', function() {
      $rootScope.loadingProgress = true;
      //$rootScope.$broadcast('loading:show');
    });

    // Desactivar indicador de carga
    var stateChangeSuccessEvent = $rootScope.$on('$stateChangeSuccess', function() {
      $timeout(function () {
        $rootScope.loadingProgress = false;
        //$rootScope.$broadcast('loading:hide');
      }, 1000);
    });

    $rootScope.$on('$stateChangeError', function(event, toState, toParams, fromState, fromParams, error) {
      if (error === "AUTH_REQUIRED") {
        ToastService.msg('fa-lock','Requiere autenticación.');
        $state.go('app.auth.login');
      }
    });

    // Cleanup
    $rootScope.$on('$destroy', function () {
      stateChangeStartEvent();
      stateChangeSuccessEvent();
    });

  }

  LoadingDirective.$inject = ['$animate'];
  /* @ngInject */
  function LoadingDirective($animate) {
    return {
      restrict: 'AE',
      template: '<div class="center">'+
                  '<div class="spinner-wrapper">'+
                    '<div class="spinner">'+
                      '<div class="inner">'+
                        '<div class="gap"></div>'+
                        '<div class="left">'+
                          '<div class="half-circle"></div>'+
                        '</div>'+
                        '<div class="right">'+
                          '<div class="half-circle"></div>'+
                        '</div>'+
                      '</div>'+
                    '</div>'+
                  '</div>'+
                '</div>',
      link: function (scope, iElement) {
        var loadingRemoveEvent = scope.$on('loading::remove', function () {
          $animate.leave(iElement).then(function () {
            // De-register scope event
            loadingRemoveEvent();

            // Null-ify everything else
            scope = iElement = null;
          });
        });
      }
    }
  }

})();
