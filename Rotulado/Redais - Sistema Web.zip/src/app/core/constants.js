(function() {
  'use strict';

  angular
    .module('app.core')
    .constant('PROTECTED_PATHS', ['/home'])
    .constant('BASEURL', window.location.origin.toString())
    .constant('CODE', 'heric1812');

})();
