(function() {
  'use strict';

  angular
    .module('app.core')
    .factory('FirebaseDataService', FirebaseDataService);

  FirebaseDataService.$inject = [];
  /* @ngInject */
  function FirebaseDataService() {
    var root = firebase.database().ref();

    var service = {
      root: root,
      profile: root.child('profile'),
      publication: root.child('publication'),
      languages: root.child('idiomas'),
      experiences: root.child('experiencias'),
      skills: root.child('habilidades'),
      listSkill: root.child('listSkill'),
    };

    return service;
  }

})();
