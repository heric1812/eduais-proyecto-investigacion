(function() {
  'use strict';

  angular
    .module('app.core')
    .factory('AuthService', AuthService);

  AuthService.$inject = ['$firebaseAuth','FirebaseDataService'];

  function AuthService($firebaseAuth,FirebaseDataService) {
    var firebaseAuthObject = $firebaseAuth();

    var service = {
      firebaseAuthObject: firebaseAuthObject,
      createProfile: createProfile,
      updateProfile: updateProfile,
      register: register,
      login: login,
      logout: logout,
      isLoggedIn: isLoggedIn,
      sendWelcomeEmail: sendWelcomeEmail,
      facebook: facebook,
      google: google,
    };

    return service;

    ////////////

    /**
     * Crear perfil - profile
     *
     * @param: uid
     *
     * @desc: Crear el perfil del usuario al registrarse
     */
    function createProfile(uid, user) {
      /*
        Con el metodo push se creará un uid para todo el objeto de datos
      return FirebaseDataService.profile.push({

        Con el metodo set se personaliza el uid que se usará para luego realizar algunas operaciones
       */
      return FirebaseDataService.profile.child(uid).set({
        avatar: user.avatar,
        nombres: user.nombres,
        apellidos: user.apellidos,
        fullName: user.nombres.toLowerCase()+' '+user.apellidos.toLowerCase(),
        cedula: user.cedula,
        fechaNacimiento: Date.parse(user.fechaNacimiento),
        sexo: user.sexo,
        emails: [user.email],
        status: 1,
        nivel: user.nivel,
        slug: getCleanedString(user.nombres)+'-'+getCleanedString(user.apellidos), /* La función para limpiar la cadena está al final */
        created: firebase.database.ServerValue.TIMESTAMP
      });
    }

    function updateProfile(user) {
      return firebase.auth().currentUser.updateProfile({
        displayName:
          user.nombres.split(' ')[0]+' '+user.apellidos.split(' ')[0]+'/'+
          user.nivel+'/'+
          getCleanedString(user.nombres)+'-'+getCleanedString(user.apellidos),
        photoURL: user.avatar
      });
    }

    /**
     * Registro
     *
     * @param: user
     *
     * @desc: Realiza el registro en la db
     */
    function register(user) {
      return firebaseAuthObject.$createUserWithEmailAndPassword(user.email, user.password);
    }

    /**
     * Login
     *
     * @param: user
     *
     * @desc: Valida las credenciales y realiza el logueo del usuario
     */
    function login(user) {
      return firebaseAuthObject.$signInWithEmailAndPassword(user.email, user.password);
    }

    /**
     * Cerrar sesión
     *
     * @param:
     *
     * @desc: Cierra la sesión del usuario activo
     */
    function logout() {
      firebaseAuthObject.$signOut();
    }

    /**
     * Esta logueado
     *
     * @param:
     *
     * @desc: Verifica si el usuario está logueado y retorna el objeto
     */
    function isLoggedIn() {
      return firebaseAuthObject.$getAuth();
    }

    /**
     * Enviar email de bienvenida
     *
     * @param: emailAddress
     *
     * @desc: Envia al email deseado un email
     */
    function sendWelcomeEmail(emailAddress) {
      FirebaseDataService.emails.push({
        emailAddress: emailAddress
      });
    }

    /**
     * Facebook
     *
     * @param:
     *
     * @desc: Loguea al usuario con su cuenta de facebook
     */
    function facebook() {
      return firebaseAuthObject.$signInWithPopup('facebook');
    }

    /**
     * Google
     *
     * @param:
     *
     * @desc: Loguea al usuario con su cuenta de google
     */
    function google() {
      return firebaseAuthObject.$signInWithPopup('google');
    }

    /**
     * Limpiar String
     *
     * @param: chain
     *
     * @desc: Se limpia una cadena (chain) de caracteres de los caracteres especiales para crear un slug limpio
     */
    function getCleanedString(chain) {
      // Definimos los caracteres que queremos eliminar
       var specialChars = "!@#$^&%*()+=-[]\/{}|:<>?,.";

      // Los eliminamos todos
      for (var i = 0; i < specialChars.length; i++) {
        chain= chain.replace(new RegExp("\\" + specialChars[i], 'gi'), '');
      }

      // Lo queremos devolver limpio en minusculas
      chain = chain.toLowerCase();

      // Quitamos espacios y los sustituimos por - porque nos gusta mas asi
      chain = chain.replace(/\s/g,"-");

      // Quitamos acentos y "ñ". Fijate en que va sin comillas el primer parametro
      chain = chain.replace(/á/gi,"a");
      chain = chain.replace(/é/gi,"e");
      chain = chain.replace(/í/gi,"i");
      chain = chain.replace(/ó/gi,"o");
      chain = chain.replace(/ú/gi,"u");
      chain = chain.replace(/ñ/gi,"n");

      return chain;
    }

  }

})();
