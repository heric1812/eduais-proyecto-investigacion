(function() {
  'use strict';

  angular
    .module('app.core')
    .factory('ExperienceService', ExperienceService);

  ExperienceService.$inject = ['$firebaseArray','FirebaseDataService','AuthService'];
  /* @ngInject */
  function ExperienceService($firebaseArray,FirebaseDataService,AuthService) {
    var service = {
      addExp: addExp,
      loadExp: loadExp,

      addSkill: addSkill,
      loadSkill: loadSkill,
      loadListSkill: loadListSkill,
    };
    return service;

    function addExp(experience) {
      var obj = $firebaseArray(FirebaseDataService.experiences);
      return obj.$add({
        userId: AuthService.isLoggedIn().uid,
        tipo: experience.tipo,
        titulo: experience.titulo,
        fechaInicio: Date.parse(experience.fechaInicio),
        fechaFin: Date.parse(experience.fechaFin),
        descripcion: experience.descripcion,
        timestamp: firebase.database.ServerValue.TIMESTAMP
      });
    }

    function loadExp(uid) {
      return $firebaseArray(FirebaseDataService.experiences.orderByChild('userId').equalTo(uid));
    }

    // Habilidades personales

    function addSkill(sk) {
      var obj = $firebaseArray(FirebaseDataService.skills);
      return obj.$add({
        userId: AuthService.isLoggedIn().uid,
        tipo: sk.tipo.$id,
        habilidad: sk.habilidad,
        porcentaje: Number(sk.porcentaje),
        timestamp: firebase.database.ServerValue.TIMESTAMP
      });
    }

    function loadSkill(uid) {
      return $firebaseArray(FirebaseDataService.skills.orderByChild('userId').equalTo(uid));
    }

    function loadListSkill() {
      return $firebaseArray(FirebaseDataService.listSkill);
    }
  }

})();