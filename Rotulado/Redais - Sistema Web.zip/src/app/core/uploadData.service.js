(function() {
  'use strict';

  angular
    .module('app.core')
    .factory('UploadDataService', UploadDataService);

  UploadDataService.$inject = [];
  /* @ngInject */
  function UploadDataService() {
    var storage = firebase.storage().ref();

    var service = {
      storage: storage,
      avatares: storage.child('avatars'),
      files: storage.child('files'),
    };
    return service;
  }

})();