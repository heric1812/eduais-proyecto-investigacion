(function() {
  'use strict';

  angular
    .module('app.navigation', [])
    .controller('NavigationController', NavigationController);

  NavigationController.$inject = ['$mdSidenav','$mdDialog','$firebaseArray','AuthService'];
  /* @ngInject */
  function NavigationController($mdSidenav,$mdDialog,$firebaseArray,AuthService) {
    var vm = this;
    // vm.user = UserService.getUserAuth();
    vm.user = {
      uid: AuthService.isLoggedIn().uid,
      avatar: AuthService.isLoggedIn().photoURL,
      name: AuthService.isLoggedIn().displayName.split('/')[0],
      level: Number(AuthService.isLoggedIn().displayName.split('/')[1]),
      slug: AuthService.isLoggedIn().displayName.split('/')[2]
    };

    vm.publications = $firebaseArray(firebase.database().ref('publication').orderByChild('prioridad').equalTo('alta'));

    // metodos
    vm.open = open;
    //////////

    activate();

    function open(ev,uid) {
      $mdDialog.show({
        controller: 'ViewPublicationController as vm',
        templateUrl: 'app/modules/publication/dialog/view-publication.html',
        parent: angular.element(document.body),
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false, // Only for -xs, -sm breakpoints.
        locals: {
          Id: uid
        }
      });
    }

     /**
     * Activate
     *
     * @param:
     *
     * @desc: Esta función se activará automáticamente al cargarse el controlador.
     */
    function activate() {
    }

  }

})();
