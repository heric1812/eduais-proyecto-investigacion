(function() {
  'use strict';

  angular
    .module('app.toolbar', [])
    .controller('ToolbarController', ToolbarController);

  ToolbarController.$inject = ['$scope','$mdSidenav','$mdDialog','AuthService','UserService','$firebaseArray','$q'];
  /* @ngInject */
  function ToolbarController($scope,$mdSidenav,$mdDialog,AuthService,UserService,$firebaseArray,$q) {
    var vm = this;
    vm.user = UserService.getUserAuth();

    vm.selectedItem = null;
    vm.searchText = null;

    // metodos

    vm.newPublication = newPublication;
    vm.toggleSidenav = toggleSidenav;
    vm.logout = logout;

    vm.getMatches = getMatches;

    //////////

    activate();

    function getMatches(query) {
      query = query.toLowerCase();
      var list = $firebaseArray(firebase.database().ref('profile').orderByChild('fullName').startAt(query).limitToFirst(3));
      return list;
    }

    /**
     * Nueva publicación
     *
     * @param: ev
     *
     * @desc: Abrir una ventana de dialogo para la creación de una nueva publicación
     */
    function newPublication(ev) {
      $mdDialog.show({
        controller: 'NewPublicationController as vm',
        templateUrl: 'app/modules/publication/dialog/new-publication.html',
        parent: angular.element(document.body),
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false // Only for -xs, -sm breakpoints.
      });
    }

     /**
     * Toggle Sidenav
     *
     * @param: sidenavId
     *
     * @desc: Función para mostrar u ocultar el sidenav seleccionado con la
     * variable sidenavId la cual alvergará el Id del sidenav que se desee ocultar o mostrar.
     */
    function toggleSidenav(sidenavId) {
      $mdSidenav(sidenavId).toggle();
    }

    /**
     * Cerrar sesión
     *
     * @param:
     *
     * @desc: Cierra la sesión del usuario.
     */
    function logout() {
      AuthService.logout();
    }

     /**
     * Activate
     *
     * @param:
     *
     * @desc: Esta función se activará automáticamente al cargarse el controlador.
     */
    function activate() {
    }
  }

})();
