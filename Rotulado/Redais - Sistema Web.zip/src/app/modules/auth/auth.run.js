(function() {
  'use strict';

  angular
    .module('app.auth')
    .run(RunFunction);

  RunFunction.$inject = ['$location','$state','AuthService','PROTECTED_PATHS'];
  /* @ngInject */
  function RunFunction($location,$state,AuthService,PROTECTED_PATHS) {

    AuthService.firebaseAuthObject.$onAuthStateChanged(function(authData) {
      if (!authData && pathIsProtected($location.path())) {
        AuthService.logout();
        $state.go('app.auth.login');
      }
    });

    function pathIsProtected(path) {
      return PROTECTED_PATHS.indexOf(path) !== -1;
    }
  }

})();
