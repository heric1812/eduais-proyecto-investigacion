(function() {
  'use strict';

  angular
    .module('app.auth', [])
    .config(Configurate);

  Configurate.$inject = ['$stateProvider'];
  /* @ngInject */
  function Configurate($stateProvider) {
    $stateProvider
      .state('app.auth', {
        abstract: true,
        url: '/account',
        cache: false,
        views: {
          'main@': {
            templateUrl: 'app/layouts/content/content-only-right.html',
            controller: 'MainController as vm'
          },
          'navigation@app.auth': {
            templateUrl: 'app/layouts/navigation/navigation-list-publications.html',
            controller: 'NavigationController as vm'
          }
        }
      })

      .state('app.auth.login', {
        url: '/login',
        views: {
          'content@app.auth': {
            templateUrl: 'app/modules/auth/login.html',
            controller: 'AuthController as vm'
          }
        },
        bodyClass: 'auth'
      })

      .state('app.auth.register', {
        url: '/register',
        views: {
          'content@app.auth': {
            templateUrl: 'app/modules/auth/register.html',
            controller: 'AuthController as vm'
          }
        },
        bodyClass: 'auth'
      })

      .state('app.auth.recover', {
        url: '/recover-password',
        views: {
          'content@app.auth': {
            templateUrl: 'app/modules/auth/recover-password.html',
            controller: 'AuthController as vm'
          }
        },
        bodyClass: 'auth'
      });
  }

})();
