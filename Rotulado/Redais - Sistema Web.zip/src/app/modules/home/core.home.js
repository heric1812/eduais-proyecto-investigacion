(function() {
  'use strict';

  angular
    .module('app.home', [])
    .config(Configurate);

  Configurate.$inject = ['$stateProvider'];
  /* @ngInject */
  function Configurate($stateProvider) {
    $stateProvider
      .state('app.home', {
        url: '/home',
        cache: false,
        views: {
          'content@app': {
            templateUrl: 'app/modules/home/home.html',
            controller: 'HomeController as vm'
          }
        },
        resolve: {
          User: ResolveUser
        },
        bodyClass: 'home',
      });
  }

  ResolveUser.$inject = ['AuthService'];
  /* @ngInject */
  function ResolveUser(AuthService) {
    return AuthService.firebaseAuthObject.$requireSignIn();
  }

  ResolveFiles.$inject = ['$ocLazyLoad'];
  /* @ngInject */
  function ResolveFiles($ocLazyLoad) {
    return $ocLazyLoad.load([
      // Array de todos los archivos que se deban cargar
      "app/modules/home/home.controller.js"
    ]).then(function() {
      // inject de modulos
      // angular.inject();
    }, function(e) {
      console.log(e);
    });
  }

})();
