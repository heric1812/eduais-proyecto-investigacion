// mpadron@unerg.edu.ve
(function() {
  'use strict';

  angular
    .module('app.home')
    .controller('HomeController', HomeController);

  HomeController.$inject = ['$mdDialog','$firebaseObject','PublicationService','User','ToastService'];
  /* @ngInject */
  function HomeController($mdDialog,$firebaseObject,PublicationService,User,ToastService) {
    var vm = this;
    vm.title = 'HomeController';

    vm.userLogin = User;
    vm.error = null;
    vm.progress = true;
    vm.list = PublicationService.list();

    // metodos
    vm.openPublication = openPublication;
    vm.editPublication = editPublication;
    vm.deletePublication = deletePublication;
    ////////////////

    activate();

    function openPublication(ev,uid) {
      $mdDialog.show({
        controller: 'ViewPublicationController as vm',
        templateUrl: 'app/modules/publication/dialog/view-publication.html',
        parent: angular.element(document.body),
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false, // Only for -xs, -sm breakpoints.
        locals: {
          Id: uid
        }
      });
    }

    function editPublication(ev,uid) {
      $mdDialog.show({
        controller: 'EditPublicationController as vm',
        templateUrl: 'app/modules/publication/dialog/new-publication.html',
        parent: angular.element(document.body),
        targetEvent: ev,
        clickOutsideToClose: true,
        fullscreen: false, // Only for -xs, -sm breakpoints.
        locals: {
          Id: uid
        }
      });
    }

    function deletePublication(uid) {
      return $firebaseObject(firebase.database().ref().child('publication').child(uid)).$remove()
        .then(function(response) {
          ToastService.success('Eliminado correctamente');
        })
        .catch(function(error) {
          ToastService.error('Error al eliminar');
        });
    }

     /**
     * Activate
     *
     * @param:
     *
     * @desc: Esta función se activará automáticamente al cargarse el controlador.
     */
    function activate() {
      console.log(vm.title);
      console.log(vm.list);
    }
  }

})();
