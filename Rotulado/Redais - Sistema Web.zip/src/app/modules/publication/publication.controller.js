(function() {
  'use strict';

  angular
    .module('app.publication')
    .controller('PublicationController', PublicationController)
    .controller('NewPublicationController', NewPublicationController)
    .controller('ViewPublicationController', ViewPublicationController)
    .controller('EditPublicationController', EditPublicationController);

  PublicationController.$inject = [];
  /* @ngInject */
  function PublicationController() {
    var vm = this;
    vm.title = 'PublicationController';

    // metodos

    //////////

    activate();

    /**
     * Activate
     *
     * @param:
     *
     * @desc: Funcion que se activa al cargar el controlador
     */
    function activate() {
      console.log(vm.title);
    }
  }


  NewPublicationController.$inject = ['$scope','$mdDialog','textAngularManager','FileUploader','ToastService','PublicationService','AuthService'];
  /* @ngInject */
  function NewPublicationController($scope,$mdDialog,textAngularManager,FileUploader,ToastService,PublicationService,AuthService) {
    var vm = this;
    vm.title = 'NewPublicationController';

    vm.data = {
      prioridad: 'baja',
      descripcion: '',
      tags: [],
      adjuntos: []
    };
    vm.readonly = false;

    // metodos
    vm.add = add;
    vm.cancel = cancel;

    //////////

    activate();

    // $scope.$watch('vm.files', function(newVal, oldVal) {
    //   console.log('newVal: ',newVal);
    //   console.log('oldVal: ',oldVal);
    //   if (newVal.length!==0) {
    //     angular.forEach(newVal, function(item, i) {
    //       var file = newVal[i];
    //       var storage = firebase.storage().ref().child(AuthService.isLoggedIn().uid).child('adjuntos').child(file.name);
    //       var uploadTask = storage.put(file);

    //       uploadTask.on('state_changed',
    //         function(snapshot) {
    //           var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
    //           vm.files[i].progress = null;
    //           console.info('subiendo: '+progress+'%');
    //           $scope.$watch('progress', function() {
    //             return vm.files[i].progress = progress;
    //           });
    //         },
    //         function(err) {
    //           // funcion al generarse un error
    //           console.error(err);
    //         },
    //         function() {
    //           vm.data.adjuntos.push({
    //             name: file.name,
    //             downloadURL: uploadTask.snapshot.downloadURL
    //           });
    //         }
    //       );
    //     });
    //   } else {
    //     console.log('0 files');
    //   }
    // });

    vm.upload = $scope.uploader = new FileUploader({
      uploadAll: function() {
        var files = vm.upload.queue;
        angular.forEach(files, function(item, i) {
          var file = item._file;
          var storage = firebase.storage().ref().child(AuthService.isLoggedIn().uid).child('adjuntos').child(file.name);
          var uploadTask = storage.put(file);

          uploadTask.on('state_changed',
            function(snapshot) {
              vm.upload.queue[i].progress = Math.floor((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
              $scope.$apply();
            },
            function(err) {
              // funcion al generarse un error
              console.error(err);
            },
            function() {
              vm.data.adjuntos.push({
                name: file.name,
                downloadURL: uploadTask.snapshot.downloadURL
              });
              vm.data.upload = true;
              ToastService.success('Subida satisfactoria '+file.name);
            }
          );
        });
      }
    });

    /**
     * Guardar
     *
     * @param: publication
     *
     * @desc: Guarda la publicación en la base de datos
     */
    function add(publication) {
      console.log(publication);
      if (publication.upload) {
        return PublicationService.newPublication(publication)
          .then(function(response) {
            ToastService.success('Publicado con exito');
            console.info('Publicado: ', response);
            cancel();
          })
          .catch(function(error) {
            ToastService.error('Error al guardar. Intentelo nuevamente');
            console.error('Error: ', error);
          });
      } else {
        vm.upload.uploadAll();
        add(publication);
      }
    }

    /**
     * Cancelar
     *
     * @param:
     *
     * @desc: Cancela la ventana de dialogo
     */
    function cancel() {
      $mdDialog.cancel();
    }

    /**
     * Activate
     *
     * @param:
     *
     * @desc: Funcion que se activa al cargar el controlador
     */
    function activate() {
      console.log(vm.title);
    }
  }


  ViewPublicationController.$inject = ['$firebaseObject','$mdDialog','Id'];
  /* @ngInject */
  function ViewPublicationController($firebaseObject,$mdDialog,Id) {
    var vm = this;
    vm.title = 'ViewPublicationController';

    vm.data = $firebaseObject(firebase.database().ref('publication/'+Id));

    // metodos
    vm.cancel = cancel;

    //////////

    activate();

    /**
     * Cancelar
     *
     * @param:
     *
     * @desc: Cancela la ventana de dialogo
     */
    function cancel() {
      $mdDialog.cancel();
    }

    /**
     * Activate
     *
     * @param:
     *
     * @desc: Funcion que se activa al cargar el controlador
     */
    function activate() {
      console.log(vm.title);
    }
  }


  EditPublicationController.$inject = ['$scope','$mdDialog','textAngularManager','FileUploader','ToastService','PublicationService','AuthService','$firebaseObject','Id'];
  /* @ngInject */
  function EditPublicationController($scope,$mdDialog,textAngularManager,FileUploader,ToastService,PublicationService,AuthService,$firebaseObject,Id) {
    var vm = this;
    vm.title = 'EditPublicationController';

    vm.data = $firebaseObject(firebase.database().ref('publication/'+Id));
    vm.readonly = false;

    // metodos
    vm.add = add;
    vm.cancel = cancel;

    //////////

    activate();

    vm.upload = $scope.uploader = new FileUploader({
      uploadAll: function() {
        var files = vm.upload.queue;
        angular.forEach(files, function(item, i) {
          var file = item._file;
          var storage = firebase.storage().ref().child(AuthService.isLoggedIn().uid).child('adjuntos').child(file.name);
          var uploadTask = storage.put(file);

          uploadTask.on('state_changed',
            function(snapshot) {
              vm.upload.queue[i].progress = Math.floor((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
              $scope.$apply();
            },
            function(err) {
              // funcion al generarse un error
              console.error(err);
            },
            function() {
              vm.data.adjuntos.push({
                name: file.name,
                downloadURL: uploadTask.snapshot.downloadURL
              });
              vm.data.upload = true;
              ToastService.success('Subida satisfactoria '+file.name);
            }
          );
        });
      }
    });

    /**
     * Guardar
     *
     * @param: publication
     *
     * @desc: Guarda la publicación en la base de datos
     */
    function add(publication) {
      console.log(publication);
      if (publication.upload) {
        return PublicationService.newPublication(publication)
          .then(function(response) {
            ToastService.success('Publicado con exito');
            console.info('Publicado: ', response);
            cancel();
          })
          .catch(function(error) {
            ToastService.error('Error al guardar. Intentelo nuevamente');
            console.error('Error: ', error);
          });
      } else {
        vm.upload.uploadAll();
        add(publication);
      }
    }

    /**
     * Cancelar
     *
     * @param:
     *
     * @desc: Cancela la ventana de dialogo
     */
    function cancel() {
      $mdDialog.cancel();
    }

    /**
     * Activate
     *
     * @param:
     *
     * @desc: Funcion que se activa al cargar el controlador
     */
    function activate() {
      console.log(vm.title);
      console.log(vm.data);
    }
  }

})();
