(function() {
  'use strict';

  angular
    .module('app.welcome', [])
    .config(Configurate);

  Configurate.$inject = ['$stateProvider'];
  /* @ngInject */
  function Configurate($stateProvider) {
    $stateProvider
      .state('app.welcome', {
        url: '/',
        // cache: false,
        views: {
          'main@': {
            templateUrl: 'app/layouts/content/content-only.html',
            controller: 'MainController as vm'
          },
          'content@app.welcome': {
            templateUrl: 'app/modules/welcome/welcome.html',
            controller: 'WelcomeController as vm'
          }
        },
        bodyClass: 'welcome',
      });
  }

})();
