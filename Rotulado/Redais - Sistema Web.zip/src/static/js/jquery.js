(function(){
  'use strict';

  /**
   * Agrega estilos al Fab Speed Dial del toolbar al realizar el evento scroll
   */
  jQuery(window).on('scroll', function() {

    var toolbarHeight = jQuery('md-toolbar').height();

    if (jQuery(window).scrollTop() > toolbarHeight) {
      jQuery('md-fab-speed-dial').css({
        position: 'fixed',
        top: '20px',
        right: '20px'
      }).addClass('animated slideInDown');
    } else {
      jQuery('md-fab-speed-dial').css({
        position: 'absolute',
        top: '20px',
        right: '20px'
      }).removeClass('animated slideInDown');
    }
  });

})();
