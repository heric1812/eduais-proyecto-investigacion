(function() {
  'use strict';

  /**
   * Credenciales de Firebase
   */
  var config = {
    apiKey: "AIzaSyD8gJsB6aMeSxzZ5OCtouqM4Ludwu5QNPw",
    authDomain: "redais-c7c70.firebaseapp.com",
    databaseURL: "https://redais-c7c70.firebaseio.com",
    storageBucket: "redais-c7c70.appspot.com",
    messagingSenderId: "415338307425"
  };

  firebase.initializeApp(config);

})();
